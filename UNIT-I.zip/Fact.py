def Fact(n):
  if(n==1):
    return 1
  else:
    return n*Fact(n-1)
n=int(input("enter a number:\n"))
print("factorial of given number:",n,"is",Fact(n))